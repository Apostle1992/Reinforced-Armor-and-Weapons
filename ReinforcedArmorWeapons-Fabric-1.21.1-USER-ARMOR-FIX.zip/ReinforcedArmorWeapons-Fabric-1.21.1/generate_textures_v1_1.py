from PIL import Image
from pathlib import Path
import colorsys, json, hashlib

ROOT = Path(__file__).resolve().parent
ITEM_DIR = ROOT / 'src/main/resources/assets/reinforcedgear/textures/item'
ARMOR_DIR = ROOT / 'src/main/resources/assets/reinforcedgear/textures/models/armor'
EDIT_DIR = ROOT / 'editable_texture_sources'

UPLOADS = {
    'layer_1': EDIT_DIR / 'V1_1_DIAMOND_MASTER_layer_1.png',
    'layer_2': EDIT_DIR / 'V1_1_DIAMOND_MASTER_layer_2.png',
    'helmet': EDIT_DIR / 'V1_1_DIAMOND_MASTER_helmet.png',
    'chestplate': EDIT_DIR / 'V1_1_DIAMOND_MASTER_chestplate.png',
    'leggings': EDIT_DIR / 'V1_1_DIAMOND_MASTER_leggings.png',
    'boots': EDIT_DIR / 'V1_1_DIAMOND_MASTER_boots.png',
    'sword': EDIT_DIR / 'V1_1_DIAMOND_MASTER_sword.png',
    'pickaxe': EDIT_DIR / 'V1_1_DIAMOND_MASTER_pickaxe.png',
    'axe': EDIT_DIR / 'V1_1_DIAMOND_MASTER_axe.png',
    'shovel': EDIT_DIR / 'V1_1_DIAMOND_MASTER_shovel.png',
    'hoe': EDIT_DIR / 'V1_1_DIAMOND_MASTER_hoe.png',
}

# These match the hue language already used by the mod's 1.0 textures.
TARGET_HUES = {
    'copper': 24.0,
    'gold': 48.0,
    'emerald': 142.0,
}
MATERIALS = ['copper', 'iron', 'gold', 'emerald', 'diamond']
GEAR = ['helmet', 'chestplate', 'leggings', 'boots', 'sword', 'pickaxe', 'axe', 'shovel', 'hoe']

def is_diamond_material(r, g, b, a):
    if a == 0:
        return False
    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    deg = h * 360.0
    # New masters use turquoise/diamond hues; neutral reinforced trim and handles stay untouched.
    return s >= 0.16 and 145.0 <= deg <= 195.0

def recolor_pixel(px, material):
    r, g, b, a = px
    if material == 'diamond' or not is_diamond_material(r,g,b,a):
        return px
    if material == 'iron':
        # Existing 1.0 iron mapping is exactly the midpoint of the min/max channels.
        gray = int(round((min(r,g,b) + max(r,g,b)) / 2.0))
        return (gray, gray, gray, a)
    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    nr, ng, nb = colorsys.hsv_to_rgb(TARGET_HUES[material]/360.0, s, v)
    return (int(round(nr*255)), int(round(ng*255)), int(round(nb*255)), a)

def recolor_image(src, material):
    im = Image.open(src).convert('RGBA')
    out = Image.new('RGBA', im.size)
    out.putdata([recolor_pixel(px, material) for px in im.getdata()])
    return out

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

EDIT_DIR.mkdir(parents=True, exist_ok=True)

# Armor entity layers
for layer_key, layer_num in [('layer_1',1), ('layer_2',2)]:
    src = UPLOADS[layer_key]
    for mat in MATERIALS:
        out = recolor_image(src, mat)
        out.save(ARMOR_DIR / f'reinforced_{mat}_layer_{layer_num}.png')

# Inventory armor, weapons, and tools
for gear in GEAR:
    src = UPLOADS[gear]
    for mat in MATERIALS:
        out = recolor_image(src, mat)
        out.save(ITEM_DIR / f'reinforced_{mat}_{gear}.png')

# Validation report
report = {
    'version': '1.1.0',
    'masters': {},
    'checks': {},
    'errors': []
}
for key, src in UPLOADS.items():
    im=Image.open(src).convert('RGBA')
    report['masters'][key]={'size':list(im.size),'sha256':sha256(src)}

for layer_key, layer_num in [('layer_1',1),('layer_2',2)]:
    master=Image.open(UPLOADS[layer_key]).convert('RGBA')
    for mat in MATERIALS:
        p=ARMOR_DIR/f'reinforced_{mat}_layer_{layer_num}.png'
        im=Image.open(p).convert('RGBA')
        ok_size=im.size==master.size==(64,32)
        ok_alpha=[x[3] for x in im.getdata()]==[x[3] for x in master.getdata()]
        report['checks'][p.name]={'size_ok':ok_size,'alpha_mask_identical':ok_alpha}
        if not (ok_size and ok_alpha): report['errors'].append(p.name)

for gear in GEAR:
    master=Image.open(UPLOADS[gear]).convert('RGBA')
    for mat in MATERIALS:
        p=ITEM_DIR/f'reinforced_{mat}_{gear}.png'
        im=Image.open(p).convert('RGBA')
        ok_size=im.size==master.size==(16,16)
        ok_alpha=[x[3] for x in im.getdata()]==[x[3] for x in master.getdata()]
        report['checks'][p.name]={'size_ok':ok_size,'alpha_mask_identical':ok_alpha}
        if not (ok_size and ok_alpha): report['errors'].append(p.name)

# Diamond output must be pixel-identical to user master.
for key in ['layer_1','layer_2']:
    n=1 if key=='layer_1' else 2
    target=ARMOR_DIR/f'reinforced_diamond_layer_{n}.png'
    identical=Image.open(target).convert('RGBA').tobytes()==Image.open(UPLOADS[key]).convert('RGBA').tobytes()
    report['checks'][target.name]['pixel_identical_to_user_master']=identical
    if not identical: report['errors'].append(target.name+':not_identical')
for gear in GEAR:
    target=ITEM_DIR/f'reinforced_diamond_{gear}.png'
    identical=Image.open(target).convert('RGBA').tobytes()==Image.open(UPLOADS[gear]).convert('RGBA').tobytes()
    report['checks'][target.name]['pixel_identical_to_user_master']=identical
    if not identical: report['errors'].append(target.name+':not_identical')

report['status']='PASS' if not report['errors'] else 'FAIL'
(ROOT/'validation-report-v1.1.json').write_text(json.dumps(report, indent=2))
print(json.dumps({'status':report['status'],'textures_checked':len(report['checks']),'errors':report['errors']}, indent=2))
