# 1.1 build notes

Version 1.1.0 is a texture-only update. Java classes, registrations, recipes and balance logic are unchanged from 1.0.0.

The distributed 1.1.0 JAR was produced by taking the existing 1.0.0 Minecraft 1.21.1 Fabric JAR and replacing only:

- `assets/reinforcedgear/textures/`
- the expanded `fabric.mod.json` version string (`1.0.0` → `1.1.0`)

This keeps the compiled gameplay code byte-for-byte unchanged while delivering the new assets.

The source project has `mod_version=1.1.0` and can also be rebuilt normally with Java 21 and Gradle/Fabric Loom.
