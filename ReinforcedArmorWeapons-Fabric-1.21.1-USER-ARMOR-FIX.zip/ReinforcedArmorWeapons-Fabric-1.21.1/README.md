# Reinforced Armor and Weapons — Fabric 1.21.1

A Vanilla+ equipment mod implementing reinforced Copper, Iron, Gold, Emerald and Diamond armor, weapons and tools.

## Implemented progression

1. Smelt **1 Iron Block** into **3 Reinforced Plates**.
   - Furnace, blast furnace and smoker recipes are included so the recipe works in the furnace variants.
2. Craft **1 Reinforced Plate + 1 material item** to make that material's **Etched Reinforced Plate**.
   - Copper Ingot
   - Iron Ingot
   - Gold Ingot
   - Emerald
   - Diamond
3. Craft armor with the normal vanilla armor patterns, replacing ingots/gems with Etched Reinforced Plates.
4. Craft tools/weapons with the normal vanilla patterns, replacing the head/blade material with Etched Reinforced Plates and replacing sticks with **Blackened Iron Rods**.

## Blackened Iron Rod recipe

The design request specified Blackened Iron Rod handles but did not specify the rod's recipe, so this prototype uses:

- 1 Iron Ingot
- 1 Coal or Charcoal
- Output: 2 Blackened Iron Rods

This is intentionally isolated to one JSON recipe and can be changed without touching Java code.

## Balance interpretation

### Armor

"One extra bar" is implemented as **+2 armor points per individual piece**, because one full armor icon on the Minecraft HUD represents two armor points.

Armor durability is **exactly 4x** the selected base material durability multiplier.

| Set | Helmet | Chest | Legs | Boots | Full armor points | Durability baseline |
|---|---:|---:|---:|---:|---:|---:|
| Reinforced Copper | 4 | 7 | 6 | 4 | 21 | 12 × 4 |
| Reinforced Iron | 4 | 8 | 7 | 4 | 23 | 15 × 4 |
| Reinforced Gold | 4 | 7 | 5 | 3 | 19 | 7 × 4 |
| Reinforced Emerald | 5 | 10 | 8 | 5 | 28 | 36 × 4 |
| Reinforced Diamond | 5 | 10 | 8 | 5 | 28 | 33 × 4 |

Copper has no vanilla armor baseline, so this prototype puts it between Gold and Iron. Emerald uses Diamond protection/toughness and a slightly higher durability multiplier.

### Tools and weapons

- Durability: **3x** baseline.
- Mining speed: **+20%**.
- Material attack-damage bonus: **+20%**.
- Attack cooldown/swing speed: kept vanilla-like to preserve the Vanilla+ feel.
- Emerald: Diamond-equivalent mining/attack stats, but 1717 base durability before the 3x reinforcement multiplier (5151 final).

Tool durability values:

| Material | Final durability |
|---|---:|
| Copper | 600 |
| Iron | 750 |
| Gold | 96 |
| Emerald | 5151 |
| Diamond | 4683 |

## Art direction

The included textures follow the supplied references rather than radically redesigning vanilla equipment:

- 16×16 item sprites
- Mostly cold grey/silver reinforced plating
- Visible dark backing and rivets
- Small material-colored etched accents
- Blackened-iron handles instead of wooden sticks
- Standard flat vanilla armor/tool silhouettes rather than 3D add-on geometry

## Build

Requirements:

- Java 21
- Gradle 8.x or a standard Fabric Gradle wrapper
- Internet access on the first build so Gradle can download Minecraft/Fabric dependencies

From the project root:

```bash
gradle build
```

The built JAR will be placed under `build/libs/`.

This source tree targets Minecraft 1.21.1 with Fabric Loader, Fabric API and Yarn mappings declared in `gradle.properties`.

## Project structure

- `src/main/java/dev/reinforcedgear/` — registration and material/stat logic
- `src/main/resources/data/reinforcedgear/recipe/` — all crafting/cooking recipes
- `src/main/resources/data/minecraft/tags/item/` — vanilla tool/armor/enchantment tag integration
- `src/main/resources/assets/reinforcedgear/` — language, models and textures

## Tuning points

The balance numbers are deliberately centralized:

- Armor durability/protection: `ModArmorMaterials.java`
- Tool durability/speed/damage: `ModToolMaterials.java`
- Axe/hoe cooldown profiles: `ModGear.java`
- Recipes: JSON under `data/reinforcedgear/recipe/`

That makes later balance passes straightforward without rewriting the mod architecture.
