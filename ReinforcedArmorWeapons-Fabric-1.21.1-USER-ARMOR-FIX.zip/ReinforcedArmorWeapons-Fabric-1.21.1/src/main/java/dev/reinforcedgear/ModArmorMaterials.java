package dev.reinforcedgear;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;

import java.util.List;
import java.util.Map;

public final class ModArmorMaterials {
    // Armor durability is exactly 4x the chosen material baseline.
    // Vanilla baselines: gold 7, iron 15, diamond 33.
    // Copper baseline: 12 (custom, between gold and iron).
    // Emerald baseline: 36 (diamond-equivalent protection, ~9% more durability).
    public static final int COPPER_DURABILITY_MULTIPLIER = 12 * 4;
    public static final int IRON_DURABILITY_MULTIPLIER = 15 * 4;
    public static final int GOLD_DURABILITY_MULTIPLIER = 7 * 4;
    public static final int EMERALD_DURABILITY_MULTIPLIER = 36 * 4;
    public static final int DIAMOND_DURABILITY_MULTIPLIER = 33 * 4;
    // Netherite vanilla durability multiplier is 37; Reinforced Netherite lasts exactly 4x as long.
    public static final int NETHERITE_DURABILITY_MULTIPLIER = 37 * 4;

    // One full armor icon = 2 armor points, so each reinforced piece adds +2
    // to its material's normal piece value.
    public static final RegistryEntry.Reference<ArmorMaterial> COPPER = register(
        "reinforced_copper", 4, 7, 6, 4, 12,
        ModItems.COPPER_ETCHED_REINFORCED_PLATE, 0.0F
    );

    public static final RegistryEntry.Reference<ArmorMaterial> IRON = register(
        "reinforced_iron", 4, 8, 7, 4, 9,
        ModItems.IRON_ETCHED_REINFORCED_PLATE, 0.0F
    );

    public static final RegistryEntry.Reference<ArmorMaterial> GOLD = register(
        "reinforced_gold", 4, 7, 5, 3, 25,
        ModItems.GOLD_ETCHED_REINFORCED_PLATE, 0.0F
    );

    public static final RegistryEntry.Reference<ArmorMaterial> EMERALD = register(
        "reinforced_emerald", 5, 10, 8, 5, 10,
        ModItems.EMERALD_ETCHED_REINFORCED_PLATE, 2.0F
    );

    public static final RegistryEntry.Reference<ArmorMaterial> DIAMOND = register(
        "reinforced_diamond", 5, 10, 8, 5, 10,
        ModItems.DIAMOND_ETCHED_REINFORCED_PLATE, 2.0F
    );


    public static final RegistryEntry.Reference<ArmorMaterial> NETHERITE = registerNetherite();

    private ModArmorMaterials() {}


    private static RegistryEntry.Reference<ArmorMaterial> registerNetherite() {
        Map<ArmorItem.Type, Integer> defense = Map.of(
            ArmorItem.Type.HELMET, 4,
            ArmorItem.Type.CHESTPLATE, 12,
            ArmorItem.Type.LEGGINGS, 10,
            ArmorItem.Type.BOOTS, 4,
            ArmorItem.Type.BODY, 0
        );

        ArmorMaterial material = new ArmorMaterial(
            defense,
            15,
            SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE,
            () -> Ingredient.ofItems(ModItems.INFUSED_NETHERITE_PLATE),
            List.of(new ArmorMaterial.Layer(ReinforcedGearMod.id("reinforced_netherite"))),
            3.0F,
            0.0F
        );

        return Registry.registerReference(
            Registries.ARMOR_MATERIAL,
            ReinforcedGearMod.id("reinforced_netherite"),
            material
        );
    }

    private static RegistryEntry.Reference<ArmorMaterial> register(
        String id,
        int helmet,
        int chestplate,
        int leggings,
        int boots,
        int enchantability,
        Item repairItem,
        float toughness
    ) {
        Map<ArmorItem.Type, Integer> defense = Map.of(
            ArmorItem.Type.HELMET, helmet,
            ArmorItem.Type.CHESTPLATE, chestplate,
            ArmorItem.Type.LEGGINGS, leggings,
            ArmorItem.Type.BOOTS, boots,
            ArmorItem.Type.BODY, 0
        );

        ArmorMaterial material = new ArmorMaterial(
            defense,
            enchantability,
            SoundEvents.ITEM_ARMOR_EQUIP_IRON,
            () -> Ingredient.ofItems(repairItem),
            List.of(new ArmorMaterial.Layer(ReinforcedGearMod.id(id))),
            toughness,
            0.0F
        );

        return Registry.registerReference(
            Registries.ARMOR_MATERIAL,
            ReinforcedGearMod.id(id),
            material
        );
    }

    public static void init() {
        // Triggers static registration.
    }
}
