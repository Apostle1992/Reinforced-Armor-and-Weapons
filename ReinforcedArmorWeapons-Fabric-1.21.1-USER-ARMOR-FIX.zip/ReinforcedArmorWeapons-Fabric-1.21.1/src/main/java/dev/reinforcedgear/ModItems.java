package dev.reinforcedgear;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModItems {
    public static final Item REINFORCED_PLATE = register("reinforced_plate");
    public static final Item BLACKENED_IRON_ROD = register("blackened_iron_rod");
    public static final Item INFUSED_BLAZE_POWDER = register("infused_blaze_powder");
    public static final Item INFUSED_NETHERITE_PLATE = registerFireproof("infused_netherite_plate");

    public static final Item COPPER_ETCHED_REINFORCED_PLATE = register("copper_etched_reinforced_plate");
    public static final Item IRON_ETCHED_REINFORCED_PLATE = register("iron_etched_reinforced_plate");
    public static final Item GOLD_ETCHED_REINFORCED_PLATE = register("gold_etched_reinforced_plate");
    public static final Item EMERALD_ETCHED_REINFORCED_PLATE = register("emerald_etched_reinforced_plate");
    public static final Item DIAMOND_ETCHED_REINFORCED_PLATE = register("diamond_etched_reinforced_plate");

    private ModItems() {}

    private static Item registerFireproof(String id) {
        return Registry.register(
            Registries.ITEM,
            ReinforcedGearMod.id(id),
            new Item(new Item.Settings().fireproof())
        );
    }

    private static Item register(String id) {
        return Registry.register(
            Registries.ITEM,
            ReinforcedGearMod.id(id),
            new Item(new Item.Settings())
        );
    }

    public static void init() {
        // Triggers static registration.
    }
}
