package dev.reinforcedgear;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;

public final class ModItemGroups {
    private ModItemGroups() {}

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(ModItems.REINFORCED_PLATE);
            entries.add(ModItems.BLACKENED_IRON_ROD);
            entries.add(ModItems.INFUSED_BLAZE_POWDER);
            entries.add(ModItems.INFUSED_NETHERITE_PLATE);
            entries.add(ModItems.COPPER_ETCHED_REINFORCED_PLATE);
            entries.add(ModItems.IRON_ETCHED_REINFORCED_PLATE);
            entries.add(ModItems.GOLD_ETCHED_REINFORCED_PLATE);
            entries.add(ModItems.EMERALD_ETCHED_REINFORCED_PLATE);
            entries.add(ModItems.DIAMOND_ETCHED_REINFORCED_PLATE);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            addCombat(entries, ModGear.COPPER);
            addCombat(entries, ModGear.IRON);
            addCombat(entries, ModGear.GOLD);
            addCombat(entries, ModGear.EMERALD);
            addCombat(entries, ModGear.DIAMOND);
            addCombat(entries, ModGear.NETHERITE);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            addTools(entries, ModGear.COPPER);
            addTools(entries, ModGear.IRON);
            addTools(entries, ModGear.GOLD);
            addTools(entries, ModGear.EMERALD);
            addTools(entries, ModGear.DIAMOND);
            addTools(entries, ModGear.NETHERITE);
        });
    }

    private static void addCombat(ItemGroup.Entries entries, ModGear.GearSet set) {
        entries.add(set.helmet());
        entries.add(set.chestplate());
        entries.add(set.leggings());
        entries.add(set.boots());
        entries.add(set.sword());
    }

    private static void addTools(ItemGroup.Entries entries, ModGear.GearSet set) {
        entries.add(set.pickaxe());
        entries.add(set.axe());
        entries.add(set.shovel());
        entries.add(set.hoe());
    }
}
