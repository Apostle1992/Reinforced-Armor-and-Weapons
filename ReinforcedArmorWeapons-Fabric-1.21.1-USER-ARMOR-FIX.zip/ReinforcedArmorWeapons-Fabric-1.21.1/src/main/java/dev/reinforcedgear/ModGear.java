package dev.reinforcedgear;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

public final class ModGear {
    public static final GearSet COPPER = registerSet(
        "reinforced_copper", ModArmorMaterials.COPPER,
        ModArmorMaterials.COPPER_DURABILITY_MULTIPLIER,
        ModToolMaterials.COPPER,
        6.0F, -3.1F,
        -1.0F, -2.0F
    );

    public static final GearSet IRON = registerSet(
        "reinforced_iron", ModArmorMaterials.IRON,
        ModArmorMaterials.IRON_DURABILITY_MULTIPLIER,
        ModToolMaterials.IRON,
        6.0F, -3.1F,
        -1.0F, -2.0F
    );

    public static final GearSet GOLD = registerSet(
        "reinforced_gold", ModArmorMaterials.GOLD,
        ModArmorMaterials.GOLD_DURABILITY_MULTIPLIER,
        ModToolMaterials.GOLD,
        6.0F, -3.0F,
        0.0F, -3.0F
    );

    public static final GearSet EMERALD = registerSet(
        "reinforced_emerald", ModArmorMaterials.EMERALD,
        ModArmorMaterials.EMERALD_DURABILITY_MULTIPLIER,
        ModToolMaterials.EMERALD,
        5.0F, -3.0F,
        -3.0F, 0.0F
    );

    public static final GearSet DIAMOND = registerSet(
        "reinforced_diamond", ModArmorMaterials.DIAMOND,
        ModArmorMaterials.DIAMOND_DURABILITY_MULTIPLIER,
        ModToolMaterials.DIAMOND,
        5.0F, -3.0F,
        -3.0F, 0.0F
    );

    private ModGear() {}

    private static GearSet registerSet(
        String prefix,
        RegistryEntry<ArmorMaterial> armorMaterial,
        int armorDurabilityMultiplier,
        ToolMaterial toolMaterial,
        float axeBaseAttackDamage,
        float axeAttackSpeed,
        float hoeBaseAttackDamage,
        float hoeAttackSpeed
    ) {
        Item helmet = register(prefix + "_helmet", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.HELMET,
            new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item chestplate = register(prefix + "_chestplate", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.CHESTPLATE,
            new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item leggings = register(prefix + "_leggings", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.LEGGINGS,
            new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item boots = register(prefix + "_boots", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.BOOTS,
            new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item sword = register(prefix + "_sword", new SwordItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                SwordItem.createAttributeModifiers(toolMaterial, 3, -2.4F)
            )
        ));

        Item pickaxe = register(prefix + "_pickaxe", new PickaxeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 1.0F, -2.8F)
            )
        ));

        Item axe = register(prefix + "_axe", new AxeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, axeBaseAttackDamage, axeAttackSpeed)
            )
        ));

        Item shovel = register(prefix + "_shovel", new ShovelItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 1.5F, -3.0F)
            )
        ));

        Item hoe = register(prefix + "_hoe", new HoeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, hoeBaseAttackDamage, hoeAttackSpeed)
            )
        ));

        return new GearSet(helmet, chestplate, leggings, boots, sword, pickaxe, axe, shovel, hoe);
    }

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, ReinforcedGearMod.id(id), item);
    }

    public static void init() {
        // Triggers static registration.
    }

    public record GearSet(
        Item helmet,
        Item chestplate,
        Item leggings,
        Item boots,
        Item sword,
        Item pickaxe,
        Item axe,
        Item shovel,
        Item hoe
    ) {}
}
