package dev.reinforcedgear;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

public final class ModGear {
    public static final GearSet COPPER = registerSet(
        "reinforced_copper", ModArmorMaterials.COPPER,
        ModArmorMaterials.COPPER_DURABILITY_MULTIPLIER,
        ModToolMaterials.COPPER,
        6.0F, -3.1F,
        -1.0F, -2.0F
    );

    public static final GearSet IRON = registerSet(
        "reinforced_iron", ModArmorMaterials.IRON,
        ModArmorMaterials.IRON_DURABILITY_MULTIPLIER,
        ModToolMaterials.IRON,
        6.0F, -3.1F,
        -1.0F, -2.0F
    );

    public static final GearSet GOLD = registerSet(
        "reinforced_gold", ModArmorMaterials.GOLD,
        ModArmorMaterials.GOLD_DURABILITY_MULTIPLIER,
        ModToolMaterials.GOLD,
        6.0F, -3.0F,
        0.0F, -3.0F
    );

    public static final GearSet EMERALD = registerSet(
        "reinforced_emerald", ModArmorMaterials.EMERALD,
        ModArmorMaterials.EMERALD_DURABILITY_MULTIPLIER,
        ModToolMaterials.EMERALD,
        5.0F, -3.0F,
        -3.0F, 0.0F
    );

    public static final GearSet DIAMOND = registerSet(
        "reinforced_diamond", ModArmorMaterials.DIAMOND,
        ModArmorMaterials.DIAMOND_DURABILITY_MULTIPLIER,
        ModToolMaterials.DIAMOND,
        5.0F, -3.0F,
        -3.0F, 0.0F
    );


    public static final GearSet NETHERITE = registerNetheriteSet();

    private ModGear() {}


    private static GearSet registerNetheriteSet() {
        RegistryEntry<ArmorMaterial> armorMaterial = ModArmorMaterials.NETHERITE;
        int durability = ModArmorMaterials.NETHERITE_DURABILITY_MULTIPLIER;
        ToolMaterial toolMaterial = ModToolMaterials.NETHERITE;

        // Knockback Resistance 1 in Minecraft tooltip terms is 0.1 internally.
        // Per design: helmet has none; chest/legs/boots each carry one Netherite-sized step.
        Item helmet = register("reinforced_netherite_helmet", new ReinforcedNetheriteArmorItem(
            armorMaterial, ArmorItem.Type.HELMET,
            new Item.Settings().fireproof().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(durability)),
            4.5D, 3.0D, 0.0D
        ));
        Item chestplate = register("reinforced_netherite_chestplate", new ReinforcedNetheriteArmorItem(
            armorMaterial, ArmorItem.Type.CHESTPLATE,
            new Item.Settings().fireproof().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(durability)),
            12.0D, 3.0D, 0.1D
        ));
        Item leggings = register("reinforced_netherite_leggings", new ReinforcedNetheriteArmorItem(
            armorMaterial, ArmorItem.Type.LEGGINGS,
            new Item.Settings().fireproof().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(durability)),
            10.0D, 3.0D, 0.1D
        ));
        Item boots = register("reinforced_netherite_boots", new ReinforcedNetheriteArmorItem(
            armorMaterial, ArmorItem.Type.BOOTS,
            new Item.Settings().fireproof().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(durability)),
            4.5D, 3.0D, 0.1D
        ));

        // Target final values vs vanilla Netherite:
        // Sword 8 -> 10.4 damage, 1.6 -> 1.92 atk/s
        // Pickaxe 6 -> 7.8 damage, 1.2 -> 1.44 atk/s
        // Axe 10 -> 13 damage, 1.0 -> 1.2 atk/s
        // Shovel 6.5 -> 8.45 damage, 1.0 -> 1.2 atk/s
        // Hoe 1 -> 1.3 damage, 4.0 -> 4.8 atk/s
        Item sword = register("reinforced_netherite_sword", new SwordItem(
            toolMaterial,
            new Item.Settings().fireproof().attributeModifiers(
                createFractionalSwordAttributeModifiers(toolMaterial, 4.2D, -2.08F)
            )
        ));
        Item pickaxe = register("reinforced_netherite_pickaxe", new PickaxeItem(
            toolMaterial,
            new Item.Settings().fireproof().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 1.6F, -2.56F)
            )
        ));
        Item axe = register("reinforced_netherite_axe", new AxeItem(
            toolMaterial,
            new Item.Settings().fireproof().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 6.8F, -2.8F)
            )
        ));
        Item shovel = register("reinforced_netherite_shovel", new ShovelItem(
            toolMaterial,
            new Item.Settings().fireproof().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 2.25F, -2.8F)
            )
        ));
        Item hoe = register("reinforced_netherite_hoe", new HoeItem(
            toolMaterial,
            new Item.Settings().fireproof().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, -4.9F, 0.8F)
            )
        ));

        return new GearSet(helmet, chestplate, leggings, boots, sword, pickaxe, axe, shovel, hoe);
    }

    /**
     * Vanilla SwordItem#createAttributeModifiers accepts an integer base damage bonus,
     * which cannot represent the exact +30% Reinforced Netherite sword target.
     * Build the same two main-hand attributes manually so the sword can retain
     * fractional damage (10.4 final attack damage) and 1.92 attacks/second.
     */
    private static AttributeModifiersComponent createFractionalSwordAttributeModifiers(
        ToolMaterial material,
        double baseAttackDamage,
        float attackSpeed
    ) {
        return AttributeModifiersComponent.builder()
            .add(
                EntityAttributes.GENERIC_ATTACK_DAMAGE,
                new EntityAttributeModifier(
                    Item.BASE_ATTACK_DAMAGE_MODIFIER_ID,
                    material.getAttackDamage() + baseAttackDamage,
                    EntityAttributeModifier.Operation.ADD_VALUE
                ),
                AttributeModifierSlot.MAINHAND
            )
            .add(
                EntityAttributes.GENERIC_ATTACK_SPEED,
                new EntityAttributeModifier(
                    Item.BASE_ATTACK_SPEED_MODIFIER_ID,
                    attackSpeed,
                    EntityAttributeModifier.Operation.ADD_VALUE
                ),
                AttributeModifierSlot.MAINHAND
            )
            .build();
    }

    private static GearSet registerSet(
        String prefix,
        RegistryEntry<ArmorMaterial> armorMaterial,
        int armorDurabilityMultiplier,
        ToolMaterial toolMaterial,
        float axeBaseAttackDamage,
        float axeAttackSpeed,
        float hoeBaseAttackDamage,
        float hoeAttackSpeed
    ) {
        Item helmet = register(prefix + "_helmet", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.HELMET,
            new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item chestplate = register(prefix + "_chestplate", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.CHESTPLATE,
            new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item leggings = register(prefix + "_leggings", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.LEGGINGS,
            new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item boots = register(prefix + "_boots", new ArmorItem(
            armorMaterial,
            ArmorItem.Type.BOOTS,
            new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(armorDurabilityMultiplier))
        ));

        Item sword = register(prefix + "_sword", new SwordItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                SwordItem.createAttributeModifiers(toolMaterial, 3, -2.4F)
            )
        ));

        Item pickaxe = register(prefix + "_pickaxe", new PickaxeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 1.0F, -2.8F)
            )
        ));

        Item axe = register(prefix + "_axe", new AxeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, axeBaseAttackDamage, axeAttackSpeed)
            )
        ));

        Item shovel = register(prefix + "_shovel", new ShovelItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, 1.5F, -3.0F)
            )
        ));

        Item hoe = register(prefix + "_hoe", new HoeItem(
            toolMaterial,
            new Item.Settings().attributeModifiers(
                MiningToolItem.createAttributeModifiers(toolMaterial, hoeBaseAttackDamage, hoeAttackSpeed)
            )
        ));

        return new GearSet(helmet, chestplate, leggings, boots, sword, pickaxe, axe, shovel, hoe);
    }

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, ReinforcedGearMod.id(id), item);
    }

    public static void init() {
        // Triggers static registration.
    }

    public record GearSet(
        Item helmet,
        Item chestplate,
        Item leggings,
        Item boots,
        Item sword,
        Item pickaxe,
        Item axe,
        Item shovel,
        Item hoe
    ) {}
}
