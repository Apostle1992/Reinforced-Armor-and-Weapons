package dev.reinforcedgear;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ReinforcedGearMod implements ModInitializer {
    public static final String MOD_ID = "reinforcedgear";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        // This call order is intentional: ingredients -> materials -> equipment -> creative tabs.
        ModItems.init();
        ModArmorMaterials.init();
        ModToolMaterials.init();
        ModGear.init();
        ModItemGroups.init();

        LOGGER.info("Reinforced Armor and Weapons initialized.");
    }
}
