package dev.reinforcedgear;

import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.Locale;

/**
 * Reinforced Netherite uses exact fractional armor values that vanilla
 * ArmorMaterial cannot represent because its defense map is integer based.
 */
public final class ReinforcedNetheriteArmorItem extends ArmorItem {
    private final AttributeModifiersComponent reinforcedModifiers;

    public ReinforcedNetheriteArmorItem(
        RegistryEntry<ArmorMaterial> material,
        Type type,
        Item.Settings settings,
        double armor,
        double toughness,
        double knockbackResistance
    ) {
        super(material, type, settings);

        AttributeModifierSlot slot = switch (type) {
            case HELMET -> AttributeModifierSlot.HEAD;
            case CHESTPLATE -> AttributeModifierSlot.CHEST;
            case LEGGINGS -> AttributeModifierSlot.LEGS;
            case BOOTS -> AttributeModifierSlot.FEET;
            case BODY -> AttributeModifierSlot.BODY;
        };

        String piece = type.name().toLowerCase(Locale.ROOT);
        AttributeModifiersComponent.Builder builder = AttributeModifiersComponent.builder()
            .add(
                EntityAttributes.GENERIC_ARMOR,
                new EntityAttributeModifier(
                    ReinforcedGearMod.id("reinforced_netherite_" + piece + "_armor"),
                    armor,
                    EntityAttributeModifier.Operation.ADD_VALUE
                ),
                slot
            )
            .add(
                EntityAttributes.GENERIC_ARMOR_TOUGHNESS,
                new EntityAttributeModifier(
                    ReinforcedGearMod.id("reinforced_netherite_" + piece + "_toughness"),
                    toughness,
                    EntityAttributeModifier.Operation.ADD_VALUE
                ),
                slot
            );

        if (knockbackResistance > 0.0D) {
            builder.add(
                EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE,
                new EntityAttributeModifier(
                    ReinforcedGearMod.id("reinforced_netherite_" + piece + "_knockback_resistance"),
                    knockbackResistance,
                    EntityAttributeModifier.Operation.ADD_VALUE
                ),
                slot
            );
        }

        this.reinforcedModifiers = builder.build();
    }

    @Override
    public AttributeModifiersComponent getAttributeModifiers() {
        return reinforcedModifiers;
    }
}
