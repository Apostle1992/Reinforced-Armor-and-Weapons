package dev.reinforcedgear;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.TagKey;

import java.util.function.Supplier;

public final class ModToolMaterials {
    // Tools/weapons use 3x durability and +20% mining speed / material attack bonus.
    // Attack cooldown remains vanilla-like so the set still feels Vanilla+.
    public static final ToolMaterial COPPER = new ReinforcedToolMaterial(
        ToolMaterials.STONE.getInverseTag(),
        200 * 3,
        5.0F * 1.20F,
        1.5F * 1.20F,
        12,
        () -> Ingredient.ofItems(ModItems.COPPER_ETCHED_REINFORCED_PLATE)
    );

    public static final ToolMaterial IRON = fromVanilla(
        ToolMaterials.IRON,
        250 * 3,
        ModItems.IRON_ETCHED_REINFORCED_PLATE
    );

    public static final ToolMaterial GOLD = fromVanilla(
        ToolMaterials.GOLD,
        32 * 3,
        ModItems.GOLD_ETCHED_REINFORCED_PLATE
    );

    public static final ToolMaterial EMERALD = new ReinforcedToolMaterial(
        ToolMaterials.DIAMOND.getInverseTag(),
        1717 * 3,
        ToolMaterials.DIAMOND.getMiningSpeedMultiplier() * 1.20F,
        ToolMaterials.DIAMOND.getAttackDamage() * 1.20F,
        ToolMaterials.DIAMOND.getEnchantability(),
        () -> Ingredient.ofItems(ModItems.EMERALD_ETCHED_REINFORCED_PLATE)
    );

    public static final ToolMaterial DIAMOND = fromVanilla(
        ToolMaterials.DIAMOND,
        1561 * 3,
        ModItems.DIAMOND_ETCHED_REINFORCED_PLATE
    );

    // Reinforced Hell tier: 4x Netherite durability, 30% faster mining, and
    // a 30% stronger material attack contribution. Exact final weapon/tool
    // damage is normalized in ModGear against vanilla Netherite final damage.
    public static final ToolMaterial NETHERITE = new ReinforcedToolMaterial(
        ToolMaterials.NETHERITE.getInverseTag(),
        2031 * 4,
        ToolMaterials.NETHERITE.getMiningSpeedMultiplier() * 1.30F,
        ToolMaterials.NETHERITE.getAttackDamage() * 1.30F,
        ToolMaterials.NETHERITE.getEnchantability(),
        () -> Ingredient.ofItems(ModItems.INFUSED_NETHERITE_PLATE)
    );

    private ModToolMaterials() {}

    private static ToolMaterial fromVanilla(ToolMaterial base, int durability, Item repairItem) {
        return new ReinforcedToolMaterial(
            base.getInverseTag(),
            durability,
            base.getMiningSpeedMultiplier() * 1.20F,
            base.getAttackDamage() * 1.20F,
            base.getEnchantability(),
            () -> Ingredient.ofItems(repairItem)
        );
    }

    private record ReinforcedToolMaterial(
        TagKey<Block> inverseTag,
        int durability,
        float miningSpeed,
        float attackDamage,
        int enchantability,
        Supplier<Ingredient> repairIngredient
    ) implements ToolMaterial {
        @Override
        public int getDurability() {
            return durability;
        }

        @Override
        public float getMiningSpeedMultiplier() {
            return miningSpeed;
        }

        @Override
        public float getAttackDamage() {
            return attackDamage;
        }

        @Override
        public TagKey<Block> getInverseTag() {
            return inverseTag;
        }

        @Override
        public int getEnchantability() {
            return enchantability;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return repairIngredient.get();
        }
    }

    public static void init() {
        // Triggers static construction.
    }
}
