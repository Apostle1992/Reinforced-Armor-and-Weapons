# 1.2.0 — Reinforced Hell Update

See `BUILD_NOTES_1.2.md` for full details.

# Changelog

## 1.1.0 — Texture Polish

- Replaced all reinforced armor inventory icons with the new plated designs.
- Replaced both worn armor layers with the new darker, higher-contrast reinforced design.
- Reworked the sword, pickaxe, axe, shovel and hoe to read as heavier reinforced equipment.
- Kept the new Diamond textures pixel-identical to the supplied 1.1 masters.
- Generated Copper, Iron, Gold and Emerald variants by changing only the material coloration while preserving the shared silhouette, dark reinforcement and handles.
- No gameplay, recipe or stat changes.

- 1.2.0 patch: Added missing Reinforced Netherite armor item textures (helmet, chestplate, leggings, boots).
