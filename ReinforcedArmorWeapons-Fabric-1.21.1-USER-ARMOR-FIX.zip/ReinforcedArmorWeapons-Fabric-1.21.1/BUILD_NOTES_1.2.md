# Reinforced Armor and Weapons 1.2.0 — Reinforced Hell Update

## Added
- Infused Blaze Powder.
- Infused Netherite Plate.
- Reinforced Netherite armor, sword, pickaxe, axe, shovel, and hoe.

## Armor
- Helmet: 4.5 armor, 3 toughness, Blast Protection II, Fire Protection I.
- Chestplate: 12 armor, 3 toughness, Blast Protection II, Fire Protection II, one Netherite-sized knockback-resistance step.
- Leggings: 10 armor, 3 toughness, Blast Protection II, Fire Protection II, one Netherite-sized knockback-resistance step.
- Boots: 4.5 armor, 3 toughness, Fire Protection II, one Netherite-sized knockback-resistance step.
- Armor durability: exactly 4x vanilla Netherite.

## Weapons and tools
- Mining speed: +30% vs vanilla Netherite.
- Final attack damage: +30% vs matching vanilla Netherite item.
- Final attack speed: +20% vs matching vanilla Netherite item.
- Durability: 4x vanilla Netherite (8124 uses).

## Recipes
- Infused Blaze Powder: 1 Blaze Powder surrounded by 8 Gunpowder.
- Infused Netherite Plate: Reinforced Plate center, Netherite Ingots left/right, Infused Blaze Powder top/bottom.
- Gear uses Infused Netherite Plates in vanilla gear shapes; tools use Blackened Iron Rods.


Patch note: Added the four missing Reinforced Netherite armor inventory item textures (helmet, chestplate, leggings, boots) supplied by the user.

## Armor item icon correction
The Reinforced Netherite helmet, chestplate, leggings, and boots now use the supplied custom 16x16 inventory textures. Their item model JSON files point to `reinforcedgear:item/reinforced_netherite_*` instead of vanilla Netherite item textures.
