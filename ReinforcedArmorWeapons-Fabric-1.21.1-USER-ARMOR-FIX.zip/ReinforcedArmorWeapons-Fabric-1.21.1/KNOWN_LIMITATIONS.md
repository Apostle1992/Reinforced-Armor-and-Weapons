# Prototype validation notes

This package is a source-complete Fabric 1.21.1 prototype with generated resources and recipes.

The current sandbox has Java 21 but does not have Gradle/Fabric dependencies cached and cannot reach the Gradle/Fabric Maven servers from the build container. Because of that, the project could not be run through Loom/Gradle here to produce a verified game JAR.

What was validated locally:

- all JSON files parse successfully;
- every recipe output points at an item registered by this mod;
- every item model points at an included texture;
- all generated PNG files are readable and use Minecraft-appropriate pixel dimensions;
- project resource IDs are internally consistent;
- Java source was written against the Fabric/Yarn 1.21.1 API signatures used by the official mappings documentation.

Recommended first real-machine test:

1. Import the project into IntelliJ IDEA or VS Code with Java 21.
2. Run `gradle build` or attach a normal Fabric Gradle wrapper and run `./gradlew build`.
3. Launch a Fabric 1.21.1 dev client.
4. Verify creative-tab entries, all recipes, armor rendering, mining tiers and enchanting behavior.
